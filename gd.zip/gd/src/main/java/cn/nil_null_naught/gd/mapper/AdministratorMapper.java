package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.Administrator;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface AdministratorMapper extends MyMapper<Administrator> {
}
