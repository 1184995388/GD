package cn.nil_null_naught.gd.mapper;


import cn.nil_null_naught.gd.pojo.Menu;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface MenuMapper extends MyMapper<Menu> {

}
