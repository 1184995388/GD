package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.MenuRecipe;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface MenuRecipeMapper extends MyMapper<MenuRecipe> {
}
