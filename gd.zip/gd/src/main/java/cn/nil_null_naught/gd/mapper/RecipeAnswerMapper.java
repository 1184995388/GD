package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.RecipeAnswer;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface RecipeAnswerMapper extends MyMapper<RecipeAnswer> {

}
