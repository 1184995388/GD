package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.Recipe;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface RecipeMapper extends MyMapper<Recipe> {
}
