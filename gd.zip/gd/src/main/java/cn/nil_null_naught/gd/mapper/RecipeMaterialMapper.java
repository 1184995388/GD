package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.RecipeMaterial;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface RecipeMaterialMapper extends MyMapper<RecipeMaterial> {
}
