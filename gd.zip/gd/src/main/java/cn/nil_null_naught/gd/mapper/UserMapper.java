package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.User;
import cn.nil_null_naught.gd.utils.MyMapper;


public interface UserMapper extends MyMapper<User> {

}
