package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.UserMenu;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface UserMenuMapper extends MyMapper<UserMenu> {
}
