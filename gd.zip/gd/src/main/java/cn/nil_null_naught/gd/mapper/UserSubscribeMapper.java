package cn.nil_null_naught.gd.mapper;

import cn.nil_null_naught.gd.pojo.UserSubscribe;
import cn.nil_null_naught.gd.utils.MyMapper;

public interface UserSubscribeMapper extends MyMapper<UserSubscribe> {
}
